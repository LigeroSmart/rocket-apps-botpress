"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallbackInputEndpoint = void 0;
const accessors_1 = require("@rocket.chat/apps-engine/definition/accessors");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const Http_1 = require("../enum/Http");
const Logs_1 = require("../enum/Logs");
const Http_2 = require("../lib/Http");
const Message_1 = require("../lib/Message");
const botpress_1 = require("../lib/botpress");
class CallbackInputEndpoint extends api_1.ApiEndpoint {
    constructor() {
        super(...arguments);
        this.path = 'callback';
    }
    async post(request, endpoint, read, modify, http, persis) {
        this.app.getLogger().info(Logs_1.Logs.ENDPOINT_RECEIVED_REQUEST);
        try {
            await this.processRequest(read, modify, persis, request.content);
            return Http_2.createHttpResponse(accessors_1.HttpStatusCode.OK, { 'Content-Type': Http_1.Headers.CONTENT_TYPE_JSON }, { result: Http_1.Response.SUCCESS });
        }
        catch (error) {
            this.app.getLogger().error(`${Logs_1.Logs.ENDPOINT_REQUEST_PROCESSING_ERROR} ${error}`);
            return Http_2.createHttpResponse(accessors_1.HttpStatusCode.INTERNAL_SERVER_ERROR, { 'Content-Type': Http_1.Headers.CONTENT_TYPE_JSON }, { error: error.message });
        }
    }
    async processRequest(read, modify, persis, endpointContent) {
        const message = botpress_1.parseSinglebotpressMessage(endpointContent, '');
        await Message_1.createbotpressMessage(message.sessionId, read, modify, message);
    }
}
exports.CallbackInputEndpoint = CallbackInputEndpoint;

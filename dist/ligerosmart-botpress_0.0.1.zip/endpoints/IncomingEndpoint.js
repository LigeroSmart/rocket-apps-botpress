"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const accessors_1 = require("@rocket.chat/apps-engine/definition/accessors");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const Endpoints_1 = require("../enum/Endpoints");
const Http_1 = require("../enum/Http");
const Logs_1 = require("../enum/Logs");
const Http_2 = require("../lib/Http");
const Room_1 = require("../lib/Room");
class IncomingEndpoint extends api_1.ApiEndpoint {
    constructor() {
        super(...arguments);
        this.path = 'incoming';
    }
    async post(request, endpoint, read, modify, http, persis) {
        this.app.getLogger().info(Logs_1.Logs.ENDPOINT_RECEIVED_REQUEST);
        try {
            await this.processRequest(read, modify, persis, request.content);
            return Http_2.createHttpResponse(accessors_1.HttpStatusCode.OK, { 'Content-Type': Http_1.Headers.CONTENT_TYPE_JSON }, { result: Http_1.Response.SUCCESS });
        }
        catch (error) {
            this.app.getLogger().error(`${Logs_1.Logs.ENDPOINT_REQUEST_PROCESSING_ERROR} ${error}`);
            return Http_2.createHttpResponse(accessors_1.HttpStatusCode.INTERNAL_SERVER_ERROR, { 'Content-Type': Http_1.Headers.CONTENT_TYPE_JSON }, { error: error.message });
        }
    }
    async processRequest(read, modify, persis, endpointContent) {
        const { action, sessionId } = endpointContent;
        if (!sessionId) {
            throw new Error(Logs_1.Logs.INVALID_SESSION_ID);
        }
        switch (action) {
            case Endpoints_1.EndpointActionNames.CLOSE_CHAT:
                await Room_1.closeChat(modify, read, sessionId);
                break;
            case Endpoints_1.EndpointActionNames.HANDOVER:
                const { actionData: { targetDepartment = null } = {} } = endpointContent;
                const room = await read.getRoomReader().getById(sessionId);
                if (!room) {
                    throw new Error(Logs_1.Logs.INVALID_SESSION_ID);
                }
                const { visitor: { token: visitorToken }, department: { name = null } = {} } = room;
                if (targetDepartment && name && targetDepartment === name) {
                    throw new Error(Logs_1.Logs.INVALID_ACTION_USER_ALREADY_IN_DEPARTMENT);
                }
                await Room_1.performHandover(modify, read, sessionId, visitorToken, targetDepartment);
                break;
            default:
                throw new Error(Logs_1.Logs.INVALID_ENDPOINT_ACTION);
        }
    }
}
exports.IncomingEndpoint = IncomingEndpoint;

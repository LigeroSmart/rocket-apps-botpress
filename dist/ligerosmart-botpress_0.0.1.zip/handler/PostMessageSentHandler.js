"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rooms_1 = require("@rocket.chat/apps-engine/definition/rooms");
const Settings_1 = require("../config/Settings");
const Logs_1 = require("../enum/Logs");
const botpress_1 = require("../lib/botpress");
const Message_1 = require("../lib/Message");
const Setting_1 = require("../lib/Setting");
class PostMessageSentHandler {
    constructor(app, message, read, http, persis, modify) {
        this.app = app;
        this.message = message;
        this.read = read;
        this.http = http;
        this.persis = persis;
        this.modify = modify;
    }
    async run() {
        const { text, editedAt, room, token, sender } = this.message;
        const livechatRoom = room;
        const { id: rid, type, servedBy, isOpen, customFields } = livechatRoom;
        const botpressBotUsername = await Setting_1.getAppSettingValue(this.read, Settings_1.AppSetting.botpressBotUsername);
        if (!type || type !== rooms_1.RoomType.LIVE_CHAT) {
            return;
        }
        if (!isOpen || !token || editedAt || !text) {
            return;
        }
        if (!servedBy || servedBy.username !== botpressBotUsername) {
            return;
        }
        if (sender.username === botpressBotUsername) {
            return;
        }
        if (!text || (text && text.trim().length === 0)) {
            return;
        }
        const wakeup = await Setting_1.getAppSettingValue(this.read, Settings_1.AppSetting.botpressEnableWakeupMessage);
        const wakeupMessage = await Setting_1.getAppSettingValue(this.read, Settings_1.AppSetting.botpressWakeupMessage) || 'Start';
        const visitorToken = livechatRoom.visitor.token;
        let bp_target = rid;
        bp_target = bp_target + ':' + visitorToken;
        if (wakeup) {
            let shouldWakeup = false;
            if (customFields) {
                const alreadyWakedup = customFields.botpressAwaked;
                if (!alreadyWakedup) {
                    shouldWakeup = true;
                }
            }
            else {
                shouldWakeup = true;
            }
            if (shouldWakeup) {
                let wakeupResponse;
                try {
                    wakeupResponse = await botpress_1.sendMessage(this.read, this.http, bp_target, wakeupMessage);
                }
                catch (_a) {
                    console.log('Erro sending wakeup message to Botpress');
                }
                const roomUp = await this.modify.getExtender().extendRoom(rid, sender);
                roomUp.addCustomField('botpressAwaked', 'true');
                this.modify.getExtender().finish(roomUp);
            }
        }
        let response;
        try {
            response = await botpress_1.sendMessage(this.read, this.http, bp_target, text);
        }
        catch (error) {
            this.app.getLogger().error(`${Logs_1.Logs.BOTPRESS_REST_API_COMMUNICATION_ERROR} ${error.message}`);
            const serviceUnavailable = await Setting_1.getAppSettingValue(this.read, Settings_1.AppSetting.botpressServiceUnavailableMessage);
            await Message_1.createMessage(rid, this.read, this.modify, {
                text: serviceUnavailable ? serviceUnavailable : Settings_1.DefaultMessage.DEFAULT_botpressServiceUnavailableMessage,
            });
            return;
        }
        if (response) {
            for (const message of response) {
                await Message_1.createbotpressMessage(rid, this.read, this.modify, message);
            }
        }
    }
}
exports.PostMessageSentHandler = PostMessageSentHandler;

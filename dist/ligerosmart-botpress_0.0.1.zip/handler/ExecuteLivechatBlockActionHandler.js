"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UIKitIncomingInteractionContainer_1 = require("@rocket.chat/apps-engine/definition/uikit/UIKitIncomingInteractionContainer");
const Settings_1 = require("../config/Settings");
const Message_1 = require("../lib/Message");
const Setting_1 = require("../lib/Setting");
class ExecuteLivechatBlockActionHandler {
    constructor(app, context, read, http, persistence, modify) {
        this.app = app;
        this.context = context;
        this.read = read;
        this.http = http;
        this.persistence = persistence;
        this.modify = modify;
    }
    async run() {
        try {
            const interactionData = this.context.getInteractionData();
            const { visitor, room, container: { id, type }, value } = interactionData;
            if (type !== UIKitIncomingInteractionContainer_1.UIKitIncomingInteractionContainerType.MESSAGE) {
                return this.context.getInteractionResponder().successResponse();
            }
            const botpressBotUsername = await Setting_1.getAppSettingValue(this.read, Settings_1.AppSetting.botpressBotUsername);
            const { servedBy: { username = null } = {}, id: rid } = room;
            if (!username || botpressBotUsername !== username) {
                return this.context.getInteractionResponder().successResponse();
            }
            const appUser = await this.read.getUserReader().getAppUser(this.app.getID());
            await Message_1.createLivechatMessage(rid, this.read, this.modify, { text: value }, visitor);
            const { value: hideQuickRepliesSetting } = await this.read.getEnvironmentReader().getSettings().getById(Settings_1.AppSetting.botpressHideQuickReplies);
            if (hideQuickRepliesSetting) {
                await Message_1.deleteAllActionBlocks(this.modify, appUser, id);
            }
            return this.context.getInteractionResponder().successResponse();
        }
        catch (error) {
            this.app.getLogger().error(error);
            return this.context.getInteractionResponder().errorResponse();
        }
    }
}
exports.ExecuteLivechatBlockActionHandler = ExecuteLivechatBlockActionHandler;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EndpointActionNames;
(function (EndpointActionNames) {
    EndpointActionNames["CLOSE_CHAT"] = "close-chat";
    EndpointActionNames["HANDOVER"] = "handover";
})(EndpointActionNames = exports.EndpointActionNames || (exports.EndpointActionNames = {}));

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const settings_1 = require("@rocket.chat/apps-engine/definition/settings");
var AppSetting;
(function (AppSetting) {
    AppSetting["botpressBotUsername"] = "ligerosmart-botpress.bot";
    AppSetting["botpressServerUrl"] = "botpress_server_url";
    AppSetting["botpressBotID"] = "botpress_bot_id";
    AppSetting["botpressServiceUnavailableMessage"] = "botpress_service_unavailable_message";
    AppSetting["botpressHandoverMessage"] = "botpress_handover_message";
    AppSetting["botpressCloseChatMessage"] = "botpress_close_chat_message";
    AppSetting["botpressEnableCallbacks"] = "botpress_enable_callbacks";
    AppSetting["botpressDefaultHandoverDepartment"] = "botpress_target_handover_department";
    AppSetting["botpressHideQuickReplies"] = "botpress_hide_quick_replies";
})(AppSetting = exports.AppSetting || (exports.AppSetting = {}));
var DefaultMessage;
(function (DefaultMessage) {
    DefaultMessage["DEFAULT_botpressServiceUnavailableMessage"] = "Sorry, I'm having trouble answering your question.";
    DefaultMessage["DEFAULT_botpressHandoverMessage"] = "Transferring to an online agent";
    DefaultMessage["DEFAULT_botpressCloseChatMessage"] = "Closing the chat, Goodbye";
})(DefaultMessage = exports.DefaultMessage || (exports.DefaultMessage = {}));
exports.settings = [
    {
        id: AppSetting.botpressBotUsername,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'bot_username',
        required: true,
    },
    {
        id: AppSetting.botpressBotID,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'botpress_bot_id',
        required: true,
    },
    {
        id: AppSetting.botpressServerUrl,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'botpress_server_url',
        required: true,
    },
    {
        id: AppSetting.botpressServiceUnavailableMessage,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'botpress_service_unavailable_message',
        i18nDescription: 'botpress_service_unavailable_message_description',
        required: false,
    },
    {
        id: AppSetting.botpressCloseChatMessage,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'botpress_close_chat_message',
        i18nDescription: 'botpress_close_chat_message_description',
        required: false,
    },
    {
        id: AppSetting.botpressHandoverMessage,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'botpress_handover_message',
        i18nDescription: 'botpress_handover_message_description',
        required: false,
    },
    {
        id: AppSetting.botpressDefaultHandoverDepartment,
        public: true,
        type: settings_1.SettingType.STRING,
        packageValue: '',
        i18nLabel: 'botpress_default_handover_department',
        i18nDescription: 'botpress_default_handover_department_description',
        required: true,
    },
    {
        id: AppSetting.botpressEnableCallbacks,
        public: true,
        type: settings_1.SettingType.BOOLEAN,
        packageValue: false,
        value: false,
        i18nLabel: 'botpress_callback_message',
        i18nDescription: 'botpress_callback_message_description',
        required: true,
    },
    {
        id: AppSetting.botpressHideQuickReplies,
        public: true,
        type: settings_1.SettingType.BOOLEAN,
        packageValue: true,
        value: true,
        i18nLabel: 'botpress_hide_quick_replies',
        i18nDescription: 'botpress_hide_quick_replies_description',
        required: true,
    },
];

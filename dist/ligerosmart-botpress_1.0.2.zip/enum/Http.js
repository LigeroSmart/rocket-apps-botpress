"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Response = exports.Headers = void 0;
var Headers;
(function (Headers) {
    Headers["CONTENT_TYPE_JSON"] = "application/json";
    Headers["ACCEPT_JSON"] = "application/json";
})(Headers = exports.Headers || (exports.Headers = {}));
var Response;
(function (Response) {
    Response["SUCCESS"] = "Your request was processed successfully";
})(Response = exports.Response || (exports.Response = {}));

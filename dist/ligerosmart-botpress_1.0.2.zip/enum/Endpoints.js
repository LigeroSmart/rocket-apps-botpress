"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EndpointActionNames = void 0;
var EndpointActionNames;
(function (EndpointActionNames) {
    EndpointActionNames["CLOSE_CHAT"] = "close-chat";
    EndpointActionNames["HANDOVER"] = "handover";
    EndpointActionNames["MESSAGE"] = "message";
})(EndpointActionNames = exports.EndpointActionNames || (exports.EndpointActionNames = {}));

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LigeroSmartBotpressApp = void 0;
const Settings_1 = require("./config/Settings");
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const PostMessageSentHandler_1 = require("./handler/PostMessageSentHandler");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const IncomingEndpoint_1 = require("./endpoints/IncomingEndpoint");
class LigeroSmartBotpressApp extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async executePostMessageSent(message, read, http, persis, modify) {
        const handler = new PostMessageSentHandler_1.PostMessageSentHandler(this, message, read, http, persis, modify);
        await handler.run();
    }
    async executePreRoomUserJoined(context, read, http, persistence) {
    }
    async extendConfiguration(configuration) {
        configuration.api.provideApi({
            visibility: api_1.ApiVisibility.PUBLIC,
            security: api_1.ApiSecurity.UNSECURE,
            endpoints: [
                new IncomingEndpoint_1.IncomingEndpoint(this),
            ],
        });
        await Promise.all(Settings_1.settings.map((setting) => configuration.settings.provideSetting(setting)));
    }
}
exports.LigeroSmartBotpressApp = LigeroSmartBotpressApp;
